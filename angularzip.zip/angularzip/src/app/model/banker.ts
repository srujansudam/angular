export class Banker{
    public bankerId:number;
	public userId:string;
	public password:string;
}