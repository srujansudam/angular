import { ɵChangeDetectorStatus } from '@angular/core';

export class CreditCard{
public cardNumber:number;
public cardStatus:string;
public nameOnCard:string;
public month:number;
public year:number;
public dateOfExpiry:Date;
public timestamp:Date;
public bankId:number;
}
