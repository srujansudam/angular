import { Customer } from './customer';

export class Message{
    message:string;
    customer:Customer;
}