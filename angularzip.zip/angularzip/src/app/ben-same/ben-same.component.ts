import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ben-same',
  templateUrl: './ben-same.component.html',
  styleUrls: ['./ben-same.component.css']
})
export class BenSameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
