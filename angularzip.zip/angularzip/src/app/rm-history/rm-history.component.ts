import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rm-history',
  templateUrl: './rm-history.component.html',
  styleUrls: ['./rm-history.component.css']
})
export class RmHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
