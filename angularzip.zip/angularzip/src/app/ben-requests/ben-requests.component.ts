import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ben-requests',
  templateUrl: './ben-requests.component.html',
  styleUrls: ['./ben-requests.component.css']
})
export class BenRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
