import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BenRequestsComponent } from './ben-requests.component';

describe('BenRequestsComponent', () => {
  let component: BenRequestsComponent;
  let fixture: ComponentFixture<BenRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BenRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BenRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
