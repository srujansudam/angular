import { Component, OnInit } from '@angular/core';
import { Message } from '../model/Message';
import { LoginService } from '../service/login.service';
import { Login } from '../model/login';
import { Customer } from '../model/customer';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  customer: Customer;
  checkRole: Login;
  userId: string;
  show: boolean;

  constructor(private login: LoginService) {
    this.show = true;
  }

  ngOnInit() {
    this.customer=  this.login.customer;
  }



}


