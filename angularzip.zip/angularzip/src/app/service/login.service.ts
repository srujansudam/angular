import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, BehaviorSubject } from 'rxjs';
import { Message } from '../model/Message';
import { Banker } from '../model/banker';
import { Customer } from '../model/customer';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  baseUrl: string;
  customer: Customer;
  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/login`;
  }

  // getById(userId:string):Observable<Message>{
  //   return this.http.get<Message>(this.baseUrl,userId);
  // }

  login(userId: string): Observable<Message> {
    return this.http.get<Message>(`${this.baseUrl}/${userId}`);
  }

  bankerlogin(userId: string): Observable<Message> {
    return this.http.get<Message>(`${this.baseUrl}/${userId}`);
  }



}