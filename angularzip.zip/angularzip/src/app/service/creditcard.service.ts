import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';
import { CreditCard } from '../model/creditcard';
import { Message } from '../model/Message';
import { Customer } from '../model/customer';

@Injectable({
    providedIn: 'root'
})

export class CreditCardService {

    baseUrl: string;
    message:Message;
    customer:Customer;
    uci:number;

    constructor(private http: HttpClient) {
        this.message = JSON.parse(localStorage.getItem('message'));
        this.customer = this.message.customer;
        this.uci = this.customer.uci;
        this.baseUrl = `${environment.baseMwUrl}/creditCard/${this.uci}`;
        
    }

    viewall(): Observable<CreditCard[]> {
        return this.http.get<CreditCard[]>(this.baseUrl);
    }
    addcard(card: CreditCard): Observable<CreditCard> {
        return this.http.post<CreditCard>(this.baseUrl, card);
    }
    deletecard(cardNumber: number): Observable<any> {
        return this.http.delete<any>(`${this.baseUrl}/${cardNumber}`);
    }



}