import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { Beneficiary } from '../model/beneficiary';
 
@Injectable({
  providedIn: 'root'
})
export class BeneficiaryService {
  baseUrl: string
  baseUrl2: string
  baseUrl3: string
 
  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/beneficiary`;
    this.baseUrl2 = `${environment.baseMwUrl}/beneficiary/otherbank`;
    this.baseUrl3 = `${environment.baseMwUrl}/beneficiary/modifyinother`;
  }
 
  getAll(): Observable<Beneficiary[]> {
    return this.http.get<Beneficiary[]>(this.baseUrl);
  }
  addBeneficiary(beneficiary: Beneficiary): Observable<Beneficiary> {
    return this.http.post<Beneficiary>(this.baseUrl, beneficiary);
  }
 
  addBenOther(beneficiary: Beneficiary): Observable<Beneficiary> {
    return this.http.post<Beneficiary>(this.baseUrl2, beneficiary);
  }
  deleteBen(accountNumber: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/${accountNumber}`)
  }
  updateBen(accountNumber: number, beneficiary: Beneficiary): Observable<Beneficiary> {
    return this.http.put<Beneficiary>(`${this.baseUrl}/${accountNumber}`, beneficiary);
  }
  updateBenOther(accountNumber: number, beneficiary: Beneficiary): Observable<Beneficiary> {
    return this.http.put<Beneficiary>(`${this.baseUrl3}/${accountNumber}`, beneficiary);
  }


 
}