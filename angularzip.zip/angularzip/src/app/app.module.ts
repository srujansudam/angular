import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreditcardComponent } from './creditcard/creditcard.component';

import { AutopaymentComponent } from './autopayment/autopayment.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { BankerWelcomeComponent } from './banker-welcome/banker-welcome.component';
import { CreditRequestsComponent } from './credit-requests/credit-requests.component';
import { BenRequestsComponent } from './ben-requests/ben-requests.component';
import { RmHistoryComponent } from './rm-history/rm-history.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { ViewBenComponent } from './view-ben/view-ben.component';
import { BenSameComponent } from './ben-same/ben-same.component';
import { BenOtherComponent } from './ben-other/ben-other.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    CreditcardComponent,

    AutopaymentComponent,
    WelcomeComponent,
    BankerWelcomeComponent,
    CreditRequestsComponent,
    BenRequestsComponent,
    RmHistoryComponent,
    LoginComponent,
    ViewBenComponent,
    BenSameComponent,
    BenOtherComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
