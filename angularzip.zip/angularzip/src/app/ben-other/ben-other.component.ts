import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ben-other',
  templateUrl: './ben-other.component.html',
  styleUrls: ['./ben-other.component.css']
})
export class BenOtherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
