import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-ben',
  templateUrl: './view-ben.component.html',
  styleUrls: ['./view-ben.component.css']
})
export class ViewBenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
