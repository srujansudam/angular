import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBenComponent } from './view-ben.component';

describe('ViewBenComponent', () => {
  let component: ViewBenComponent;
  let fixture: ComponentFixture<ViewBenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewBenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
