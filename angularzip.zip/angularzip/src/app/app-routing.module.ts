import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AutopaymentComponent } from './autopayment/autopayment.component';
import { CreditcardComponent } from './creditcard/creditcard.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { BankerWelcomeComponent } from './banker-welcome/banker-welcome.component';
import { LoginComponent } from './login/login.component';
import {ViewBenComponent} from './view-ben/view-ben.component';
import{BenSameComponent} from './ben-same/ben-same.component';
import{BenOtherComponent} from './ben-other/ben-other.component';
import { from } from 'rxjs';



const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'creditcard',component:CreditcardComponent},
  {path:'autopayment',component:AutopaymentComponent},
  {path:'welcome',component:WelcomeComponent},
  {path:'login',component:LoginComponent},
  {path:'bankerlogin',component:BankerWelcomeComponent},
  {path: 'viewben', component: ViewBenComponent},
  {path: 'bensame', component:BenSameComponent},
  {path: 'benother', component: BenOtherComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
