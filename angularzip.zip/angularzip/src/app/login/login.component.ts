import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Login } from '../model/login';

import { LoginService } from '../service/login.service';
import { Message } from '../model/Message';
import { CreditCardService } from '../service/creditcard.service';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  checkRole: Login;
  message: Message;

  constructor(private loginService: LoginService, private actRt: ActivatedRoute,
    private router: Router) {
  
  }

  ngOnInit() {
    this.checkRole = new Login();
    this.message = new Message();
  }

  login() {
    if ((this.checkRole.role) == "CUSTOMER") {

      this.loginService.login(this.checkRole.userId).subscribe(
        (data) => {
          this.message = data;
          if (data.customer == null) {
            this.router.navigateByUrl('/welcome');
          } else {
            this.loginService.customer = this.message.customer;
            this.router.navigateByUrl('/welcome');
          }
        }

      );
    }
    else {
      // localStorage.setItem('bankLogin', JSON.stringify(this.checkRole));
      // this.loginService.bankerlogin(this.checkRole.userId).subscribe(
      //   (data) => {
      //     this.message = data;

      //     if (data.banker == null) {
      //       this.router.navigateByUrl('/exceptionlogin');
      //     } else {
      //       this.router.navigateByUrl('/banker-welcome');
      //     }

      //   }
      // );
    }
  }
}