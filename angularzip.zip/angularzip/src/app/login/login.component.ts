import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Login } from '../model/login';
import { LoginService } from '../service/login.service';
import { Message } from '../model/Message';
 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  checkRole: Login;
  message: Message ;
 
  constructor(private loginService: LoginService, private actRt: ActivatedRoute,
    private router: Router) {
    this.checkRole = new Login();
    this.message = new Message();
  }
 
  ngOnInit() {
 
  }
 
  login() {
    if ((this.checkRole.role) == "CUSTOMER") {
      localStorage.setItem('custLogin', JSON.stringify(this.checkRole));
      this.loginService.login(this.checkRole.userId).subscribe(
        
        (data) => {
          this.message = data;
          localStorage.setItem('message', JSON.stringify(this.message));
          if (data.customer == null) {
            this.router.navigateByUrl('/welcome');
            this.message = new Message();
          } else
            this.router.navigateByUrl('/welcome');
            this.message = new Message();
        }
 
      );
    }
    else {
      // localStorage.setItem('bankLogin', JSON.stringify(this.checkRole));
      // this.loginService.bankerlogin(this.checkRole.userId).subscribe(
      //   (data) => {
      //     this.message = data;
          
      //     if (data.banker == null) {
      //       this.router.navigateByUrl('/exceptionlogin');
      //     } else {
      //       this.router.navigateByUrl('/banker-welcome');
      //     }
 
      //   }
      // );
    }
  }
}