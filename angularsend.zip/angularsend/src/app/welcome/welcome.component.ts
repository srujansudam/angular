import { Component, OnInit } from '@angular/core';
import{LoginService} from '../service/login.service'
import { Customer } from '../model/customer';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  customer: Customer

  constructor(private login: LoginService) { 
  
  }

  ngOnInit() {

  }
 
}

