import { Component, OnInit } from '@angular/core';
import { Customer} from '../model/customer';
import {LoginService} from '../service/login.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userId:string;
  customer:Customer;

  constructor(private loginService: LoginService, private actRt: ActivatedRoute,
    private router: Router) {
    this.userId = "";
   }

  ngOnInit() {
    
  }

  login(){
    this.loginService.login(this.userId).subscribe(
        (data) => {
          this.customer = data;
          this.router.navigateByUrl("/welcome");
        }
    );
  }

  
}