import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import {Customer} from '../model/customer';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  baseUrl:string;

  constructor(private http:HttpClient) {
    this.baseUrl=`${environment.baseMwUrl}/login`;
  }

  // getById(userId:string):Observable<Customer>{
  //   return this.http.get<Customer>(this.baseUrl,userId);
  // }

  login(userId:string):Observable<Customer>{
    return this.http.get<Customer>(`${this.baseUrl}/${userId}`);
  }
  
 
}
