export class ServiceProvider{
    public spi:number;
    public nameOfCompany:string;    
}