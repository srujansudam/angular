package com.cg.ibs.rm.ui;

public enum AutoPaymentUi {
	ADDAUTOPAYMENTS, UPDATEAUTOPAYMENTS, REMOVEAUTOPAYMENTS, EXIT
}
